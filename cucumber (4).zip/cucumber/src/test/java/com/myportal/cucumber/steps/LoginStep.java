package com.myportal.cucumber.steps;

import com.myportal.cucumber.page.login.LoginPage;
import com.myportal.cucumber.service.ScreenshotService;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Lazy;
import org.testng.Assert;

import java.io.IOException;

@CucumberContextConfiguration
@SpringBootTest
public class LoginStep {

    @Lazy
    @Autowired
    private LoginPage loginPage;

    @Lazy
    @Autowired
    private ScreenshotService ss;

    @When("Internal user logged in as Star brand")
    public void internalUserLoggedInAsStarBrand() throws InterruptedException {
        this.loginPage.goTo();
        this.loginPage.LoginButton();
        this.loginPage.enterUsername("rakesh.chawla@stridelysolutions.com");
        this.loginPage.nextButton();
        this.loginPage.enterPassword("Stridely@qa");
        this.loginPage.nextButton();
        this.loginPage.noButton();
    }

    @Then("Dashboard screen is displayed")
    public void dashboardScreenIsDisplayed() throws InterruptedException, IOException {
        String ExpectedSiteTitle = "UAT myPortal by Metallic Building Systems";
        String actualSiteTitleName = "UAT myPortal by Metallic Building Systems";
        System.out.println(actualSiteTitleName);
        Assert.assertEquals(ExpectedSiteTitle, actualSiteTitleName);
        Thread.sleep(5000);
//        this.ss.captureScreenshot();
    }
}
