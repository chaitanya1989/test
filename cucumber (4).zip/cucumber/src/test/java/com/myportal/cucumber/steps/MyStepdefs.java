package com.myportal.cucumber.steps;

import com.myportal.cucumber.page.login.LoginPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.testng.Assert;

public class MyStepdefs {

    @Lazy
    @Autowired
    private LoginPage loginPage;

    @When("Internal user logged in as Metallic brand")
    public void interalUserLoggedInAsMetallicBrand() {
        this.loginPage.goTo();
        this.loginPage.LoginButton();
        this.loginPage.enterUsername("rxchawla@cornerstone-bb.com");
        this.loginPage.nextButton();
        this.loginPage.enterPassword("Success@123");
        this.loginPage.nextButton();
        this.loginPage.noButton();

    }

    @Then("Dashboard screen is display")
    public void dashboardScreenIsDisplay() throws InterruptedException {
        String ExpectedSiteTitle = "UAT myPortal by Metallic Building Systems";
        String actualSiteTitleName = "UAT myPortal by Metallic Building Systems";
        System.out.println(actualSiteTitleName);
        Assert.assertEquals(ExpectedSiteTitle, actualSiteTitleName);
        Thread.sleep(5000);
    }
}
