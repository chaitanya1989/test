package com.myportal.cucumber.steps;

import com.myportal.cucumber.page.google.GooglePage;
import com.myportal.cucumber.service.ScreenshotService;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import java.io.IOException;

public class GoogleStep {

    @Lazy
    @Autowired
    GooglePage googlePage;

    @Lazy
    @Autowired
    private ScreenshotService ss;

    @When("go to google page")
    public void goToGooglePage() {
        this.googlePage.goTo();
    }

    @Then("search {string} word")
    public void searchWord(String searchKey) throws InterruptedException, IOException {
        this.googlePage.searchKeyword(searchKey);
        this.googlePage.clickOnSearchButton();
//        this.ss.captureScreenshot();
    }
}
