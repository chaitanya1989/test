package com.myportal.cucumber.controls;

import com.myportal.cucumber.page.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Lazy
@Component
public class Commons extends Base{

    public void clickOnButton(WebDriver driver, By by){
        driver.findElement(by).click();
    }

    public void enterTextInTextBox(WebDriver driver, By by, String value){
        driver.findElement(by).sendKeys(value);
    }
}
