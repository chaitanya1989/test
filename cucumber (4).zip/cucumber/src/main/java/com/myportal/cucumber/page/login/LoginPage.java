package com.myportal.cucumber.page.login;

import com.myportal.cucumber.controls.Commons;
import com.myportal.cucumber.page.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.function.Function;

@Lazy
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class LoginPage extends Base {

    @Autowired
    private Commons commons;

    @Value("${application.url}")
    private String url;

    private By spinnerLocator = By.xpath("//*[@id='LoderSvg']");
    private By loginBtn=By.xpath("//button[normalize-space()='Login']");
    private By userNameTxtBx=By.xpath("//*[@name='loginfmt']");
    private By passwordTxtBx=By.xpath("//input[@id='i0118']");
    private By nextBtnSignIn=By.xpath("//input[@id='idSIButton9']");
    private By staySignInNoBtnLogin=By.xpath("//input[@id='idBtn_Back']");

    public void goTo(){
        driver.get(url);
        driver.manage().window().maximize();
    }

    public void LoginButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(spinnerLocator));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));
        commons.clickOnButton(driver, loginBtn);
    }

    public void enterUsername(String userName) {
        wait.until(ExpectedConditions.elementToBeClickable(userNameTxtBx));
        commons.enterTextInTextBox(driver, userNameTxtBx, userName);
    }

    public void enterPassword(String userPass) {
        wait.until(ExpectedConditions.elementToBeClickable(passwordTxtBx));
        commons.enterTextInTextBox(driver, passwordTxtBx, userPass);
    }

    public void nextButton() {
        wait.until(ExpectedConditions.elementToBeClickable(nextBtnSignIn));
        commons.clickOnButton(driver, nextBtnSignIn);
    }

    public void noButton() {
        wait.until(ExpectedConditions.elementToBeClickable(staySignInNoBtnLogin));
        commons.clickOnButton(driver, staySignInNoBtnLogin);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));
    }
}
