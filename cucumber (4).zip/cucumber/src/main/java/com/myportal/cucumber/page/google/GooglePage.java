package com.myportal.cucumber.page.google;

import com.myportal.cucumber.page.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import static io.cucumber.spring.CucumberTestContext.SCOPE_CUCUMBER_GLUE;

@Lazy
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class GooglePage extends Base {

    @Autowired
    private WebDriver driver;

    @Value("${google.url}")
    private String url;

    private By searchBox = By.name("q");

    public void goTo(){
        driver.get(url);
    }

    public void searchKeyword(String searchKey){
        wait.until(ExpectedConditions.elementToBeClickable(searchBox));
        driver.findElement(searchBox).sendKeys(searchKey);
    }

    public void clickOnSearchButton(){
        driver.findElement(searchBox).sendKeys(Keys.ENTER);
    }

}
