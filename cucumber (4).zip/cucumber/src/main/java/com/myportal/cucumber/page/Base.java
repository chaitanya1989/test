package com.myportal.cucumber.page;

import jakarta.annotation.PostConstruct;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Duration;

public class Base {

    @Autowired
    protected WebDriver driver;

    @Autowired
    protected WebDriverWait wait;

//    @Autowired
//    protected FluentWait<WebDriver> fWait;


//    public Wait<WebDriver>  fluentWait(){
//        Wait<WebDriver> fWait = new FluentWait<WebDriver>(driver)
//                .withTimeout(Duration.ofSeconds(60))
//                .pollingEvery(Duration.ofSeconds(1))
//                .ignoring(NoSuchElementException.class);
//        return fWait;
//    }
}
